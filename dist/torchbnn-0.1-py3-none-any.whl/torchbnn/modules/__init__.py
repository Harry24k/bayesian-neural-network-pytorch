from .linear import BayesLinear
from .conv import BayesConv2d
from .batchnorm import BayesBatchNorm2d